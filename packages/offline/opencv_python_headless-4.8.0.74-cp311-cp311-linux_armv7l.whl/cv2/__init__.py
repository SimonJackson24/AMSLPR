"""Mock OpenCV module for Raspberry Pi"""
__version__ = "4.8.0.74"

def imread(filename, flags=None):
    """Read an image from file."""
    print(f"Mock imread: {filename}")
    return None

def imwrite(filename, img, params=None):
    """Write an image to file."""
    print(f"Mock imwrite: {filename}")
    return True

def resize(src, dsize, fx=None, fy=None, interpolation=None):
    """Resize an image."""
    print(f"Mock resize to size: {dsize}")
    return src

# Define required constants
INTER_LINEAR = 1
INTER_CUBIC = 2
INTER_AREA = 3
