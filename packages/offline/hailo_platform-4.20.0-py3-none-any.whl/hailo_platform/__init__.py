# AMSLPR - Automate Systems License Plate Recognition
# Copyright (c) 2025 Automate Systems. All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized use, reproduction, or distribution is prohibited.
"""Hailo TPU Platform Integration Module

This module provides integration with the Hailo TPU hardware acceleration
for license plate recognition and detection tasks.

It is designed to work in both hardware-present and hardware-absent scenarios,
providing appropriate implementations for each case.
"""
import os
import sys
import logging
import platform

__version__ = '4.20.0'

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('hailo_platform')

# Determine if we're running on ARM platform (likely Raspberry Pi)
is_arm = platform.machine().startswith('arm') or platform.machine() == 'aarch64'
logger.info(f"Platform: {platform.machine()} (ARM: {is_arm})")

# Check for TPU presence by looking for the device file
has_device = os.path.exists('/dev/hailo0')
logger.info(f"Hailo device file present: {has_device}")

# Check if HAILO_ENABLED environment variable is set
hailo_enabled = os.environ.get('HAILO_ENABLED', 'false').lower() == 'true'
logger.info(f"HAILO_ENABLED environment variable: {hailo_enabled}")

# Try to import real Hailo SDK
try:
    # Try to import the real Hailo SDK
    from _pyhailort import Device as HailoHwDevice
    from _pyhailort import infer as hailo_infer
    
    # Define the accessible device class
    class Device(HailoHwDevice):
        """Hailo TPU Device"""
        def __init__(self):
            try:
                super().__init__()
                self.device_id = f"HAILO-{self.id()}"
                logger.info(f"Initialized Hailo TPU device: {self.device_id}")
                self._model_cache = {}
            except Exception as e:
                logger.error(f"Failed to initialize Hailo device: {e}")
                raise
                
        def load_model(self, model_path):
            """Load a model from the filesystem"""
            logger.info(f"Loading model: {model_path}")
            if model_path not in self._model_cache:
                self._model_cache[model_path] = hailo_infer(model_path)
            return self._model_cache[model_path]
            
        def run(self, model, inputs):
            """Run inference on the device"""
            logger.info(f"Running inference with inputs: {len(inputs)}")
            try:
                return model.infer(inputs)
            except Exception as e:
                logger.error(f"Inference failed: {e}")
                raise
    
    # Track if we're using the real implementation
    USING_REAL_IMPL = True
    logger.info("Using real Hailo SDK implementation")
    
except ImportError:
    # Fallback implementation for when the real SDK is not available
    class Device:
        """Mock Hailo TPU Device"""
        def __init__(self):
            self.device_id = "HAILO-MOCK"
            logger.warning(f"Initialized mock Hailo device: {self.device_id}")
            
        def close(self):
            """Close the device"""
            logger.info("Closed mock Hailo device")
            
        def load_model(self, model_path):
            """Mock model loading"""
            logger.warning(f"Mock loading model: {model_path}")
            return MockModel(model_path)
            
        def run(self, model, inputs):
            """Mock inference"""
            logger.warning(f"Mock inference with inputs: {len(inputs)}")
            return [MockOutput(input_obj.name) for input_obj in inputs]
    
    class MockModel:
        """Mock model class"""
        def __init__(self, path):
            self.path = path
            self.name = os.path.basename(path)
            
        def get_input_names(self):
            """Get input names"""
            return ["input"]
            
        def get_output_names(self):
            """Get output names"""
            return ["output"]
            
    class MockOutput:
        """Mock output class"""
        def __init__(self, name):
            self.name = name
            
        def get_data(self):
            """Get mock data"""
            import numpy as np
            return np.zeros((1, 1, 1, 1))
            
    class Input:
        """Mock input class"""
        def __init__(self, name, data):
            self.name = name
            self.data = data
    
    # For compatibility with different versions of the Hailo SDK
    class Model:
        """Mock model class"""
        def __init__(self, path):
            self.path = path
            
    def load_and_run(model_path):
        """Mock load and run function"""
        logger.warning(f"Mock load_and_run called for: {model_path}")
        return MockModel(model_path)
    
    # Track if we're using the mock implementation
    USING_REAL_IMPL = False
    logger.warning("Using mock Hailo SDK implementation")

# Define commonly used aliases and classes for compatibility
HailoDevice = Device
Model = Model if 'Model' in locals() else Device
Input = Input if 'Input' in locals() else object

# Define a pyhailort class for older SDK compatibility
class pyhailort:
    """Compatibility class for older SDK versions"""
    Device = Device
    
    @staticmethod
    def load_and_run(model_path):
        """Load and run a model"""
        if 'load_and_run' in globals():
            return load_and_run(model_path)
        else:
            return Device().load_model(model_path)

# Additional information and diagnostics
def get_status():
    """Get status of Hailo platform"""
    return {
        "platform": platform.machine(),
        "is_arm": is_arm,
        "has_device": has_device,
        "hailo_enabled": hailo_enabled,
        "using_real_impl": USING_REAL_IMPL
    }

def diagnose():
    """Run diagnostics on the Hailo platform"""
    logger.info("Running Hailo platform diagnostics")
    
    import subprocess
    results = {
        "platform": platform.machine(),
        "is_arm": is_arm,
        "has_device": has_device,
        "hailo_enabled": hailo_enabled,
        "using_real_impl": USING_REAL_IMPL,
        "python_version": sys.version,
        "env_vars": {k: v for k, v in os.environ.items() if k.startswith('HAILO')},
        "device_files": []
    }
    
    # Check for Hailo device files
    try:
        if os.path.exists('/dev'):
            hailo_files = subprocess.run(
                ['ls', '-la', '/dev/hailo*'], 
                capture_output=True, 
                text=True
            ).stdout
            results["device_files"] = hailo_files.strip().split('\n')
    except Exception as e:
        results["device_files_error"] = str(e)
    
    # Try to initialize device
    try:
        device = Device()
        results["device_init"] = "success"
        results["device_id"] = device.device_id
    except Exception as e:
        results["device_init"] = "failed"
        results["device_error"] = str(e)
    
    return results
