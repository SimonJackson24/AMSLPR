"""Minimal NumPy stub for ARM compatibility"""
__version__ = "1.21.0"

class ndarray:
    """Stub ndarray class"""
    def __init__(self, shape=None, dtype=None, buffer=None, offset=0,
                 strides=None, order=None):
        self.shape = shape
        self.dtype = dtype

def array(object, dtype=None, copy=True, order='K', subok=False, ndmin=0):
    """Create an array."""
    return ndarray()

def zeros(shape, dtype=float, order='C'):
    """Return a new array of given shape and type, filled with zeros."""
    return ndarray(shape=shape, dtype=dtype)

def ones(shape, dtype=float, order='C'):
    """Return a new array of given shape and type, filled with ones."""
    return ndarray(shape=shape, dtype=dtype)
