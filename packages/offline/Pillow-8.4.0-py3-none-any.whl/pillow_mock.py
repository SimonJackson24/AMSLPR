"""Minimal Pillow stub for ARM compatibility"""
__version__ = "8.4.0"

class Image:
    """Stub Image class"""
    @staticmethod
    def open(fp, mode='r', formats=None):
        """Stub open method"""
        return Image()
        
    def save(self, fp, format=None, **params):
        """Stub save method"""
        pass
