"""Minimal OpenCV stub for ARM compatibility"""
__version__ = "4.5.3.56"

def imread(filename, flags=None):
    """Stub imread method"""
    return None
    
def imwrite(filename, img, params=None):
    """Stub imwrite method"""
    return True
    
def resize(src, dsize, fx=None, fy=None, interpolation=None):
    """Stub resize method"""
    return src
