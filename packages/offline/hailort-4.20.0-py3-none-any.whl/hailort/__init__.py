"""Hailo Runtime (hailort) Module

This module provides direct integration with the Hailo TPU runtime,
facilitating hardware acceleration for deep learning models.
"""
import os
import sys
import logging
import platform
try:
    from hailo_platform import Device, load_and_run, pyhailort, HailoDevice
    from hailo_platform import USING_REAL_IMPL
    
    __version__ = "4.20.0"
    
    # Configure logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger('hailort')
    logger.info(f"Imported from hailo_platform (using real implementation: {USING_REAL_IMPL})")
except ImportError as e:
    # If hailo_platform is not available, provide minimal functionality
    __version__ = "4.20.0"
    
    # Configure logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger('hailort')
    logger.warning(f"Failed to import from hailo_platform: {e}")
    
    # Check for TPU presence by looking for the device file
    has_device = os.path.exists('/dev/hailo0')
    logger.info(f"Hailo device file present: {has_device}")
    
    # Define base device class
    class Device:
        """Hailo TPU Device"""
        def __init__(self):
            self.device_id = "HAILORT-MOCK"
            logger.warning(f"Initialized mock Hailo device: {self.device_id}")
            
        def close(self):
            """Close the device"""
            logger.info("Closed mock Hailo device")
    
    # Define load_and_run function
    def load_and_run(model_path):
        """Mock load and run function"""
        logger.warning(f"Mock load_and_run called for: {model_path}")
        return None
    
    # Create an alias for compatibility
    HailoDevice = Device
    
    # Define a pyhailort class for older SDK compatibility
    class pyhailort:
        """Compatibility class for older SDK versions"""
        Device = Device
        
        @staticmethod
        def load_and_run(model_path):
            """Load and run a model"""
            return load_and_run(model_path)
    
    # We're using the mock implementation
    USING_REAL_IMPL = False
